#include "testApp.h"
int rectX;
int rectY;
//--------------------------------------------------------------
void testApp::setup(){
    ofBackground(255,255,255);
    rectX=10;
    rectY=10;
}

//--------------------------------------------------------------
void testApp::update(){

}

//--------------------------------------------------------------
void testApp::draw(){
    ofFill();
	ofSetColor(100,100,100);
    ofRectangle rect;
    rect.x = rectX;
    rect.y = rectY;
    rect.width = 100;
    rect.height = 100;
    
    ofRect(rect);
}

//--------------------------------------------------------------
void testApp::keyPressed(int key){

}

//--------------------------------------------------------------
void testApp::keyReleased(int key){

}

//--------------------------------------------------------------
void testApp::mouseMoved(int x, int y){
    draw();
}

//--------------------------------------------------------------
void testApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::mousePressed(int x, int y, int button){
    rectX=x;
    rectY=y;
}

//--------------------------------------------------------------
void testApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void testApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void testApp::dragEvent(ofDragInfo dragInfo){ 

}